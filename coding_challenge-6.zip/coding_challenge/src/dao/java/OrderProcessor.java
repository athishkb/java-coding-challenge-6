package dao.java;
import Util.java.*;
import java.util.*;
import model.java.*;
import java.sql.*;
import exception.java.*;

public class OrderProcessor extends IOrderManagementRepository {
	
	private Connection connection;
	PreparedStatement s;
	
	public OrderProcessor(){
	     connection= DBUtil.getDBConn();
	}
	
	public void createorder(order order){
		try {
			s=connection.prepareStatement("insert into orders values(?,?,?)");
			s.setInt(1, order.getorderid());
			s.setInt(2,order.getuserid());
			s.setInt(3, order.getproductid());
			s.executeUpdate();
			System.out.println("order added");
		}
		catch(Exception e) {
			System.out.print(e);
		}

		}
	
	
	
	public void cancelOrder(int userid, int orderid) throws OrderNotFoundexception{
		try {
			s=connection.prepareStatement("delete from orders where userid=? and orderid=?");
			s.setInt(1, userid);
			s.setInt(2, orderid);
			s.executeUpdate();
			System.out.println("order removed");

		}
		catch(Exception e){
			throw new OrderNotFoundexception("order not found");
		}
		
	}
	
	
	public void createProduct( product product){
		try {
			s=connection.prepareStatement("insert into products values(?,?,?,?,?,?)");
			s.setInt(1, product.getProduct_id());
			s.setString(2, product.getProductname());
			s.setString(3, product.getDescription());
			s.setDouble(4, product.getPrice());
			s.setInt(5,product.getQuantityin_stock());
			s.setString(6,product.getType());
			s.executeUpdate();
			System.out.println("product added");

			}
		catch(Exception e) {
			System.out.print(e);
		}

		
	}
	
	
	public void createUser(user user){
		try {
			s=connection.prepareStatement("insert into users values(?,?,?,?)");
			s.setInt(1, user.getuser_id());
			s.setString(2, user.getusername());
			s.setString(3, user.getpassword());
			s.setString(4, user.getrole());
			s.executeUpdate();
			System.out.println("user added");
		}
		catch(Exception e) {
			System.out.print(e);
		}
	}
	
	
	public void getAllProducts(){
		try {
		s=connection.prepareStatement("select * from products");
        ResultSet one = s.executeQuery();
        
        while(one.next())
        {
        	System.out.print(one.getInt(1)+" ");
        	System.out.print(one.getString(2)+" ");
        	System.out.print(one.getString(3)+" ");
        	System.out.print(one.getString(4)+" ");
        	System.out.println();
        
        }
		}
		catch(Exception e) {
			System.out.print(e);
		}
	}
	
	
	public void getOrderByUser(user users) throws UserNotFoundexception {
		try {
			s=connection.prepareStatement("select orders.* from orders join users on orders.userId=users.userId where users.userId=?");
			s.setInt(1,users.getuser_id());
			ResultSet one = s.executeQuery();
			while(one.next()) {
				System.out.print(one.getInt(1)+" ");
				System.out.print(one.getInt(2)+" ");
				System.out.print(one.getInt(3)+" ");
				System.out.println();
				
			}
			
		}
	catch(Exception e) {
		throw new UserNotFoundexception("user not found");
		}
	}
	
}			

