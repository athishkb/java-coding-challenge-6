package model.java;

public class user {
		int user_id;
		String username;
		String password;
		String role;
		
		public user(){
			
		}

		public user(int user_id, String username, String password, String role) {
			super();
			this.user_id = user_id;
			this.username = username;
			this.password = password;
			this.role = role;
		}

		public int getuser_id() {
			return user_id;
		}

		public void setuser_id(int user_id) {
			this.user_id = user_id;
		}

		public String getusername() {
			return username;
		}

		public void setusername(String username) {
			this.username = username;
		}

		public String getpassword() {
			return password;
		}

		public void setpassword(String password) {
			this.password = password;
		}

		public String getrole() {
			return role;
		}

		public void setrole(String role) {
			this.role = role;
		}
		
		
}
