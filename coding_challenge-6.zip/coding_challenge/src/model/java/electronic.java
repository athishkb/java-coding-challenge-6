package model.java;

public class electronic extends product {
		String brand;
		int warrantyperiod;
		
		electronic(){
			
		}
		

		public electronic(String brand, int warrantyperiod) {
			super();
			this.brand = brand;
			this.warrantyperiod = warrantyperiod;
		}


		public String getBrand() {
			return brand;
		}

		public void setBrand(String brand) {
			this.brand = brand;
		}

		public int getWarrantyperiod() {
			return warrantyperiod;
		}

		public void setWarrantyperiod(int warrantyperiod) {
			this.warrantyperiod = warrantyperiod;
		}
		
}
