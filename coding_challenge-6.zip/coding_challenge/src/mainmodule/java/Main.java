package mainmodule.java;
import java.util.*;
import java.sql.*;
import Util.java.*;
import dao.java.*;
import exception.java.UserNotFoundexception;
import model.java.*;
public class Main {

	public static void main(String[] args)  {
		OrderProcessor op=new OrderProcessor();
		
		Scanner sc=new Scanner (System.in);
		while(true) {
			System.out.print("1.createOrder\n2.cancelOrder\n3.createProduct\n4.createuser \n5.getAllProducts\n6.getorderbyuser\n7.exit");
			System.out.println("\nenter your choice");
			int n=sc.nextInt();
			if(n==1) {
				order o=new order();
				System.out.println("Enter order id :");
				o.setorderid(sc.nextInt());
				System.out.println("Enter user ID :");
				o.setuserid(sc.nextInt());
				System.out.println("Enter product ID :");
				o.setproductid(sc.nextInt());
				op.createorder(o);
			}
			else if(n==2) {
				order o=new order();
				System.out.println("Enter order id: ");
				int orderid=sc.nextInt();
				System.out.println("Enter user id :");
				int userid=sc.nextInt();
			    try {
					op.cancelOrder(userid, orderid);
				} 
			    catch (Exception e) {
					e.getMessage();
				}
			}
			else if(n==3) {
				product p=new product();
				System.out.println("Enter product ID :");
				p.setProduct_id(sc.nextInt());
				System.out.println("Enter product name :");
				sc.nextLine();
				p.setProductname(sc.nextLine());
				System.out.println("Enter product description :");
				p.setDescription(sc.nextLine());
				System.out.println("Enter price :");
				p.setPrice(sc.nextDouble());
				System.out.println("Enter quantity in stock :");
				p.setQuantityin_stock(sc.nextInt());
				System.out.println("Enter type: ");
				sc.nextLine();
				p.setType(sc.nextLine());
				
				op.createProduct(p);
			}
			else if(n==4) {
				user u=new user();
				 System.out.println("enter userId: ");
				 u.setuser_id(sc.nextInt());
				 System.out.println("enter username");
				 u.setusername(sc.nextLine());
				 sc.nextLine();
				 System.out.println("enter password");
				 u.setpassword(sc.nextLine());
				 System.out.println("enter role");
				 u.setrole(sc.nextLine());
				 op.createUser(u);
				
			}
			else if(n==5) {
				op.getAllProducts();
			}
			else if(n==6) {
				user u=new user();
				System.out.println("enter userId: ");
				u.setuser_id(sc.nextInt());
				try {
					op.getOrderByUser(u);
				} catch (UserNotFoundexception e) {
					e.printStackTrace();
				}
			}
			else if(n==7) {
				break;
			}
			
		}
	}

}
