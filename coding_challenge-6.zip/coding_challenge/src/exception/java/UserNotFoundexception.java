package exception.java;

public class UserNotFoundexception extends Exception{
				public UserNotFoundexception(String ex) {
					super(ex);
				}
}
