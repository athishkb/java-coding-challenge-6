package Util.java;
import java.util.*;
import java.sql.*;

public class DBUtil {
	private static Connection connection = null;
	
	 DBUtil() {
     try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ordermanagement", "root", "Server#1234");
           
 
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
 
	}
 
	public static Connection getDBConn()
	 {
		DBUtil a= new DBUtil();
		 return connection;
		
	 }
 
}
